<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Gerenciar Permissões</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f3f4f6;
            margin: 0;
            padding: 0;
        }

        .topo {
            width: 100%;
            background: #111;
            color: white;
            font-family: "Brush Script MT", cursive;
            font-size: 28px;
            text-align: center;
            padding: 15px;
        }

        .container {
            max-width: 1000px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #111;
        }

        .mensagem-sucesso {
            background-color: #d1e7dd;
            color: #0f5132;
            padding: 12px;
            border: 1px solid #badbcc;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #f8f9fa;
        }

        button {
            padding: 10px 20px;
            background-color: #111;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        .voltar {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #111;
        }
    </style>
</head>
<body>

<div class="topo">Flor de Cheiro</div>

<div class="container">
    <h2>Permissões de Acesso</h2>

    <?php if (!empty($_SESSION['mensagem_sucesso'])): ?>
        <div class="mensagem-sucesso">
            <?= $_SESSION['mensagem_sucesso'] ?>
            <?php unset($_SESSION['mensagem_sucesso']); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="/florV3/public/index.php?rota=salvar-permissoes">
        <table>
            <tr>
                <th>Página</th>
                <th>Admin</th>
                <th>Colaborador</th>
                <th>Colaborador-Produção</th>
            </tr>
            <?php
            $paginas = [
                'painel', 'historico', 'agenda',
                'acompanhamento', 'acompanhamento-atendente', 'usuarios', 'novo-usuario',
                'cadastrar-produto', 'lista-produtos',
                'cadastrar-vendedor', 'lista-vendedores',
                'retiradas', 'permissoes',
                'cadastrar-pedido', 'cadastrar-entrega', 'cadastrar-retirada',
                'salvar-pedido', 'salvar-entrega', 'salvar-retirada',
                'imprimir-pedido', 'imprimir-ordem', 'imprimir-cupom-cliente'
            ];

            $tipos = ['admin', 'colaborador', 'colaborador-producao'];

            foreach ($paginas as $pagina) {
                echo "<tr><td>$pagina</td>";
                foreach ($tipos as $tipo) {
                    $checked = '';
                    foreach ($permissoes as $p) {
                        if ($p['pagina'] === $pagina && $p['tipo_usuario'] === $tipo) {
                            $checked = 'checked';
                            break;
                        }
                    }

                    // Bloqueia o admin de remover acesso à página de permissões
                    $disabled = ($pagina === 'permissoes' && $tipo === 'admin') ? 'disabled' : '';

                    echo "<td><input type='checkbox' name='permissoes[$pagina][]' value='$tipo' $checked $disabled></td>";
                }
                echo "</tr>";
            }
            ?>
        </table>
        <br>
        <div style="text-align: center;">
            <button type="submit">Salvar Permissões</button>
        </div>
    </form>
    <div style="text-align: center;">
        <a class="voltar" href="/florV3/public/index.php?rota=painel">← Voltar ao Painel</a>
    </div>
</div>

</body>
</html>
