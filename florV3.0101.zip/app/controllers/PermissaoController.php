<?php
require_once __DIR__ . '/../models/Permissao.php';

class PermissaoController {
    // Exibe o formulário de gerenciamento de permissões
    public function index() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // ⚠️ Só admin pode acessar essa página
        if (!isset($_SESSION['usuario_tipo']) || $_SESSION['usuario_tipo'] !== 'admin') {
            header('Location: /florV3/public/index.php?rota=acesso-negado');
            exit;
        }

        $permissaoModel = new Permissao();
        $permissoes = $permissaoModel->listarTodas();

        require __DIR__ . '/../views/permissoes/index.php';
    }

    // Salva permissões a partir do formulário
    public function salvar() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // ⚠️ Somente admin pode salvar
        if (!isset($_SESSION['usuario_tipo']) || $_SESSION['usuario_tipo'] !== 'admin') {
            header('Location: /florV3/public/index.php?rota=acesso-negado');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $permissaoModel = new Permissao();
            $permissaoModel->salvarPermissoes($_POST['permissoes'] ?? []);

            // ✅ Mensagem para feedback visual (opcional)
            $_SESSION['mensagem_sucesso'] = 'Permissões atualizadas com sucesso!';

            // 🛑 Redireciona de volta para a própria página de permissões (e não painel)
            header('Location: /florV3/public/index.php?rota=permissoes');
            exit;
        } else {
            echo "Método não permitido.";
            exit;
        }
    }
}
