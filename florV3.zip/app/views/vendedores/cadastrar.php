<h2>Cadastro de Vendedor</h2>
<form action="/florV3/public/index.php?rota=salvar-vendedor" method="POST">
    <label>Nome: <input type="text" name="nome" required></label><br><br>
    <label>Telefone: <input type="text" name="telefone" required></label><br><br>
    <button type="submit">Salvar</button>
</form>
