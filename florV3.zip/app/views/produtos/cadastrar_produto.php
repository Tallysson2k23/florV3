<h2>Cadastrar Produto</h2>
<form action="/florV3/public/index.php?rota=salvar-produto" method="POST">
    <label>Nome do Produto:</label><br>
    <input type="text" name="nome" required><br><br>
    <button type="submit">Salvar</button>
</form>
