<h3>Escolha o tipo de pedido</h3>
<a href="/florV3/public/index.php?rota=cadastrar-entrega">
    <button>Entrega</button>
</a>
<a href="/florV3/public/index.php?rota=cadastrar-retirada">
    <button>Retirada</button>
</a>
<a href="/florV3/public/index.php?rota=painel">
    <button style="margin-bottom: 20px;">⬅ Voltar ao Painel</button>
</a>