<?php
require_once __DIR__ . '/../../config/database.php';

class Operador {
    private $conn;
    private $table = 'operadores';

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function listarTodos() {
        $sql = "SELECT id, nome FROM {$this->table} ORDER BY nome ASC";
        return $this->conn->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }
}
